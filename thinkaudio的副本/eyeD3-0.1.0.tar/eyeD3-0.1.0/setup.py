from distutils.core import setup;
setup(
  name="eyeD3",
  url="http://pyid3.sourceforge.net/",
  description="Python ID3 Tools",
  author="Travis Shirk",
  author_email="travis@pobox.com",
  version="0.0.2",
  package_dir={'eyeD3': 'src/eyeD3'},
  packages=["eyeD3"]
)

